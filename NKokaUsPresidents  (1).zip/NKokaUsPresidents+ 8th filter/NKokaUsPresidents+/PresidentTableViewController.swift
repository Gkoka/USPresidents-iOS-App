//
//  SearchResultTableTableViewController.swift
//  NKokaUsPresidents+
//
//  Created by Gayatri on 27/10/18.
//  Copyright © 2018 Northern Illinois University. All rights reserved.
/*
 
 Author:     Naga Gayatri Koka
 Z-ID:       Z1823454
 Course:     CSCI 521, Fall 2018
 DUE:        11:59 p.m., Friday, 11/09/2018
 Instructor: Kaisone Rush
 TA:         Rajarshi Sen
 Description:
 1) This app is a tab based application. It has 3 tabs. The first tab displays all 45 presidents of United States. The user can search for a particular president, filter results based on educated or not, or presidents who served less than an year or can find the youngest and oldest presdients. The user can also sort the results based on name or party, or by order in which they became presdient. TableViewController is used to display Presidents. Each cell has president image, name, years served and party associated. When row is selected then the view will transfer to the detail view.
 2) The second tab displays all the presidents same like the first tab. But the difference is that, the user can do nested search i.e he can search for president who have no education and then among them he can select the youngest or oldest president. TableViewController is used to display Presidents. Each cell has president image, name, years served and party associated. When row is selected then the view will transfer to the detail view. And, the user can also view the number of president founds for each search.
 3) Detail view consists of details about the service years, date of birth, date of death, term, party, vice president, education, birth place, spouse, website, facts about that president, and also the user can hear the facts. The detail view consists of website button when clicked, the external website is loaded. When the facts button is clicked the facts will be displayed by a modal view controller.
 4) The third tab displays the details about the app. The about app view has send email feedback button , text view and about author button. The text view consists of details about the application. When send email feedback button is pressed, it composes a new email. When about author button is pressed view will transfer to about author view.
 5) About author view has webkit view which displays details of author who developed the application. Those details are presented in the form of a webpage.
 
 */


import UIKit
import AVFoundation

/* PresidentTableViewController represents the president view. This controller will control the data flow for the presidents table view. This displays images, name, title, subtitle and party of each president. It also has search bar to search for the particular president. It has the filter bar button on the left and sort button on the right. The filter button is used to filter the results based on the selected item from the action sheet. The sort button is used for sorting the presidentes based on the part, name or order.
 */

//Adding UISearchBarDelegate as header to this class
class PresidentTableViewController: UITableViewController,UISearchBarDelegate {
    
    //Declare each President as struct
    struct President : Decodable{
        let number : String?
        let name : String?
        let birth : String?
        let death : String?
        let term : String?
        let startYear : String?
        let endYear : String?
        let vp : String?
        let party : String?
        let birthPlace : String?
        let spouse : String?
        let education : String?
        let image : String?
        let website : String?
        let facts : String?
        
    }//end struct

    //Declaring the president object for the structure created above
    var presidentObject = [President]()
    //Creating the searchObject for storing the presidents based on search results
    var searchObject = [President]()
    
    //Outlets to display data
    @IBOutlet weak var searchField: UISearchBar!
    
    //filterButton function is used to filter the results based on the selected field of action sheet
    @IBAction func filterButton(_ sender: UIBarButtonItem) {
        
        //Setting title for the action sheet
        let filterActionSheet = UIAlertController(title: "Please select one", message: nil, preferredStyle: .actionSheet)
        //Adding the action Youngest President for filter action sheet
        filterActionSheet.addAction(UIAlertAction(title: "Youngest President", style: .default, handler: { ACTION in
            //variables to compare ages
            var highestAge = 150
            var lowestMonth = 0
            var lowestDay = 0
            var index: Int?  //variable to store index
            
            //for presidentIndex in self.presidentObject.indices
            for presidentIndex in self.presidentObject.indices
            {
                //Storing the values after spliting
                var birthDate = self.presidentObject[presidentIndex].birth?.split(separator: " ")
                //Storing the year
                let year = Int(self.presidentObject[presidentIndex].startYear!)! - Int(birthDate![2])!
                //storing the month
                let month = self.convertMonthIntoInt(month: String(birthDate![0]))
                //Storing the value after spliting
                let dayObject = birthDate![1].split(separator: ",")
                //Storing the day
                let day = Int(dayObject[0])!
                
                //condition for checking year
                if year == highestAge
                {
                    //condition for checking month
                    if(month > lowestMonth)
                    {
                        lowestMonth = month
                    }//end if
                    else if (month == lowestMonth)
                    {
                        if day > lowestDay
                        {
                            lowestDay = day
                        }
                    }//end if
                    
                    //storing the index
                    index = presidentIndex
                }
                //condition for checking the highest year
                else if year < highestAge
                {
                    highestAge = year
                    lowestMonth = month
                    lowestDay = day
                    index = presidentIndex
                    
                }//end if
            }//end for
            
            //remove all the data from the search object
            self.searchObject.removeAll()
            //if index is not nil
            if (index != nil)
            {
                 //appending to search object
                self.searchObject.append(self.presidentObject[index!])
            }//end if
             //Reloading the table view data
            self.tableView.reloadData()
            
            //checks if the highest is not 150
            if(highestAge != 150)
            {
                //Displaying the alert with the age
                let alertController = UIAlertController(title: nil, message: "Found youngest president with age of \(highestAge)", preferredStyle: .alert)
                //Add action close to the alert controller
                alertController.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
                //presenting the alert controller
                self.present(alertController,animated: true,completion: nil)
            }//end if
        }))//end addAction
        
        //Adding the action Oldest President for filter action sheet
        filterActionSheet.addAction(UIAlertAction(title: "Oldest President", style: .default, handler: { ACTION in
            //variables used for comparing the ages
            var lowestAge = -50
            var highestMonth = 13
            var highestDay = 32
            var index: Int?
            
            //for loop
            for presidentIndex in self.presidentObject.indices
            {
                //Storing the values after spliting
                var birthDate = self.presidentObject[presidentIndex].birth?.split(separator: " ")
                //Storing the year
                let year = Int(self.presidentObject[presidentIndex].startYear!)! - Int(birthDate![2])!
                //storing the month
                let month = self.convertMonthIntoInt(month: String(birthDate![0]))
                //Storing the value after spliting
                let dayObject = birthDate![1].split(separator: ",")
                //storing the day
                let day = Int(dayObject[0])!
                
                //condition for finding the highest age
                //Checking the year
                if year == lowestAge
                {
                    //condition for checking month
                    if(month < highestMonth)
                    {
                        highestMonth = month
                    }
                    else if (month == highestMonth)
                    {
                        if day < highestDay
                        {
                            highestDay = day
                        }
                    }//end else if
                    
                    //storing the index
                    index = presidentIndex
                }
                //condition for checking the lowest year
                else if year > lowestAge
                {
                    lowestAge = year
                    highestMonth = month
                    highestDay = day
                    index = presidentIndex
                }
            }//End for
            
            //remove all the data from the search object
            self.searchObject.removeAll()
            
            ////if index is not nil
            if(index != nil)
            {
                //appending to search object
                self.searchObject.append(self.presidentObject[index!])
            }
            //Reloading the table view data
            self.tableView.reloadData()
            
            //checks if the lowest is not -50
            if(lowestAge != -50)
            {
                //Displaying the alert with the age
                let alertController = UIAlertController(title: nil, message: "Found oldest president with age \(lowestAge)", preferredStyle: .alert)
                //Add action close to the alert controller
                alertController.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
                //presenting the alert controller
                self.present(alertController,animated: true,completion: nil)
            }
        }))
        
        //Adding the action With Education for filter action sheet
        filterActionSheet.addAction(UIAlertAction(title: "With Education", style: .default, handler: { ACTION in
            
            //remove the data from search object
            self.searchObject.removeAll()
            
            //for loop to read the records of president object
            for presidentIndex in self.presidentObject.indices
            {
                //checks if the education is not none
                if self.presidentObject[presidentIndex].education != "None"
                {
                    //appending the data to search object
                    self.searchObject.append(self.presidentObject[presidentIndex])
                }
            }
            //Reloading the table view data
            self.tableView.reloadData()
        }))
        
        //Adding the action No Education for filter action sheet
        filterActionSheet.addAction(UIAlertAction(title: "No education", style: .default, handler: { ACTION in
            
            //remove the data from search object
            self.searchObject.removeAll()
            
            //for loop to read the records of president object
            for presidentIndex in self.presidentObject.indices
            {
                //checks if the education is none
                if self.presidentObject[presidentIndex].education == "None"
                {
                    //appending the data to search object
                    self.searchObject.append(self.presidentObject[presidentIndex])
                }
            }
            //Reloading the table view data
            self.tableView.reloadData()
        }))
        
        //Adding the action Served less than 1 year for filter action sheet
        filterActionSheet.addAction(UIAlertAction(title: "Served less than 1 year", style: .default, handler: { ACTION in
            
            //remove the data from search object
            self.searchObject.removeAll()
            
            //for loop to read the records
            for presidentIndex in self.presidentObject.indices
            {
                //holds the end year
                let Year = self.presidentObject[presidentIndex].endYear!
                //if end year is empty then it is 2018
                let endYear = Year.isEmpty ? 2018 : Int(Year)
                //holds the start year
                let startYear = Int(self.presidentObject[presidentIndex].startYear!)
                
                //Checking if the served years is less than 1
                if (endYear! - startYear!) < 1
                {
                    //appending the data to search object
                    self.searchObject.append(self.presidentObject[presidentIndex])
                }
            }
            //Reloading the table view data
            self.tableView.reloadData()
        }))
        
        //Adding the action Cancel for filter action sheet
        filterActionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        //Presenting the action sheet
        self.present(filterActionSheet,animated: true,completion: nil)
    }
    
    //convertMonthIntoInt returns the associated int value for the month
    func convertMonthIntoInt(month: String) -> Int
    {
        //switch statement
        switch month.lowercased()
        {
        case "january": return 1
        case "february": return 2
        case "march": return 3
        case "april": return 4
        case "may": return 5
        case "june": return 6
        case "july": return 7
        case "august": return 8
        case "september": return 9
        case "october": return 10
        case "november": return 11
        case "december": return 12
        default:
            return 0
        }//end switch
    }//end func
    
    //sortButton function is used to sort the results based on the selected field of action sheet
    @IBAction func sortButton(_ sender: UIBarButtonItem)
    {
        //Setting title for the action sheet
        let sortActionSheet = UIAlertController(title: "Please select one", message: nil, preferredStyle: .actionSheet)
        
        //Adding the action Default(Number) for sort action sheet
        sortActionSheet.addAction(UIAlertAction(title: "Default(Number)", style: .default, handler: { ACTION in
            
            //if the selected item is Default(Number)
            self.searchObject.sort(by: { obj1,obj2 in
                //returning the sorted values based on the order
                return Int(obj1.number!)! < Int(obj2.number!)!
            })
            //Reloading the table view data
            self.tableView.reloadData()
        }))
        
        //Adding the action Name for sort action sheet
        sortActionSheet.addAction(UIAlertAction(title: "Name", style: .default, handler: { ACTION in
            //if the selected item is Name
            self.searchObject.sort(by: { obj1,obj2 in
                //returning the sorted values based on the names
                return obj1.name! < obj2.name!
            })
            //Reloading the table view data
            self.tableView.reloadData()
        }))
        
        //Adding the action Party for sort action sheet
        sortActionSheet.addAction(UIAlertAction(title: "Party", style: .default, handler: { ACTION in
            //if the selected item is Party
            self.searchObject.sort(by: { obj1,obj2 in
                //returning the sorted values based on the party
                return obj1.party! < obj2.party!
            })
            //Reloading the table view data
            self.tableView.reloadData()
        }))
        //Adding the action Cancel for sort action sheet
        sortActionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        //Presenting the action sheet
        self.present(sortActionSheet,animated: true, completion: nil)
    }
    
    //After the initial view loads, call the fetchJasonData method to
    //load and parse json presidents list from "http://faculty.cs.niu.edu/~krush/f18/presidents-json."
    //Implementing the viewDidLoad function
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Setting the table view height
        self.tableView.rowHeight = 150
        
        //Setting the background image for the table view
        let backImage = UIImageView(image: UIImage(named: "inner.jpeg"))
        self.tableView.backgroundView = backImage
        self.tableView.backgroundView?.alpha = 0.09
        
        //Calling the function fetchJasonData
        fetchJasonData()
        
        //Setting the search field delegate to self
        searchField.delegate = self
    }
    
    /* This function submits a url request to get the json formatted data from the source as indicated in url String.
     */
    func fetchJasonData()
    {
        //This URL contains my API key, fetching the data.
        guard let api_url = URL(string: "http://faculty.cs.niu.edu/~krush/f18/presidents-json") else {return}
        //Create a URL request with the API address
        let urlRequest = URLRequest(url: api_url)
        //Submit a request to get the JSON data
        let task = URLSession.shared.dataTask(with: urlRequest)
        {
            (data, response, error) in
            //if there is an error, print the error and do not continue
            if error != nil {
                print(error!)
                return
            }//end if
            
            //If there is no error, fetch the json formatted content
            if let content = data {
                do {
                    //Serializing the JSON object
                    let jsonObject = try
                        JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    
                    //Fetch only the presidents
                    if let presidentJson = jsonObject["US presidents"]
                        as? [[String: AnyObject]] {
                        //for loop
                        //Storing the data into struct variables
                        for eachPresident in presidentJson {
                            let number = eachPresident["number"] as? String
                            let title = eachPresident["president"] as? String
                            let birthDate = eachPresident["dob"] as? String
                            let deathDate = eachPresident["dod"] as? String
                            let term = eachPresident["terms"] as? String
                            let startYear = eachPresident["start_year"] as? String
                            let endYear = eachPresident["end_year"] as? String
                            let vp = eachPresident["vp"] as? String
                            let party = eachPresident["party_affiliation"] as? String
                            let birthPlace = eachPresident["birthplace"] as? String
                            let spouse = eachPresident["first_lady"] as? String
                            let education = eachPresident["college_edu"] as? String
                            let image = eachPresident["image_1"] as? String
                            let website = eachPresident["website"] as? String
                            let facts = eachPresident["facts"] as? String
                            
                            //Calling the president structure
                            let president = President(number: number!, name: title, birth: birthDate, death: deathDate, term: term, startYear: startYear, endYear: endYear, vp: vp, party: party, birthPlace: birthPlace, spouse: spouse, education: education, image: image, website: website, facts: facts)
                            
                            //Appending the data into president object
                            self.presidentObject.append(president);
                            //initializing the search object to president object
                            self.searchObject = self.presidentObject
                        }
                        //to make sure that the table data gets populated once the JSON data is decoded
                        DispatchQueue.main.async {   self.tableView.reloadData() }
                    } else {
                        let error = "Couldn't create an president object from the JSON"
                        print(error)
                    }
                } catch {
                    print("Check the JSON that is being read")
                    return
                }
            }
        }
        task.resume()
        // print(" \(presidentObject)")
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    //number of sections in the table view
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    //returns the count of search object
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return searchObject.count
    }

    //This function sets the data for each cell.
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Identify the cell with identifier as CELL and set that details from the object fetched above
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! PresidentTableViewCell
        
        // Configure the cell...
        let president: President = searchObject[indexPath.row]
        
        //let cellImageName = UIImage(named: president.image!)
        //cell.PresidentCellImageView.image = cellImageName
        //Getting the image based on the URL given
        if let url = URL(string: president.image!){
            do{
                let x = try Data(contentsOf: url)
                cell.PresidentCellImageView.image = UIImage(data:x);
            }
            catch let ImageError {
                print("Unable to read image",ImageError)
            }
        }
        //set the image, title, subtitle, party of each President
        //For rounding the image
        cell.PresidentCellImageView.layer.borderWidth = 1
        cell.PresidentCellImageView.layer.masksToBounds = false
        cell.PresidentCellImageView.layer.borderColor = UIColor.black.cgColor
        cell.PresidentCellImageView.layer.cornerRadius = cell.PresidentCellImageView.frame.height/2
        cell.PresidentCellImageView.clipsToBounds = true
        
        cell.PresidentTitle.text = president.name
        cell.PresidentSubtitle.text = president.startYear! + "-" + (president.endYear!.isEmpty ? "Present" : president.endYear!)
        cell.PresidentParty.text = president.party
        //Setting the cell background color to clear
        cell.backgroundColor = .clear
        //returns the cell
        return cell
    }
    //Sets the variables of the destination view controller
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("In detail segue 1")
        //To identify whether DETAIL segue is activated
        if (segue.identifier == "DETAIL") {
            print("In detail segue 2")
            //Assign the value of destination viewController to destVC
            let destVC = segue.destination as! PresidentDetailViewController
            
            //getting the selected row
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let president : President = searchObject[indexPath.row]
                //Setting the values of the destVC
                destVC.image = president.image
                destVC.facts = president.facts
                destVC.name = president.name
                destVC.dob = president.birth
                destVC.dod = president.death
                destVC.term = president.term
                destVC.startYear = president.startYear
                destVC.endYear = president.endYear
                destVC.birthPlace = president.birthPlace
                destVC.spouse = president.spouse
                destVC.education = president.education
                destVC.vp = president.vp
                destVC.website = president.website
                destVC.party = president.party
                destVC.facts = president.facts
                destVC.synthesizer = AVSpeechSynthesizer()
                
            }
        }
    }
    //This function is used to implement the search bar functionality
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        //guard statement for checking the search text
        guard !searchText.isEmpty else {
            searchObject = presidentObject
            //reload the data of table view
            tableView.reloadData()
            return
        }
        
        //Search the text we entered by converting it to lower case
        searchObject = presidentObject.filter({President -> Bool in
            guard let x = searchField.text?.lowercased() else { return false }
            //get the full name of employee into the variable and search for it
            let nameSearch = President.name!
            let partySearch = President.party!
            let startYearSearch = President.startYear!
            let endYearSearch = President.endYear!
            let y = Int(x)
            //if the entered text is year display the records with that year and records containing that year between start and end years
            if y != nil
            {
                let beforeYear = Int(startYearSearch)
                let afterYear = (Int(endYearSearch) == nil ? 2018 : Int(endYearSearch))
                //condition for checking if that year is between start and end years
                if y! >= beforeYear! && y! <= afterYear!
                {
                    return true
                }
                
            }
            //return the records found
            return (nameSearch.lowercased().contains(x) || partySearch.lowercased().contains(x) || startYearSearch.contains(x) || endYearSearch.contains(x))
        })
        
        //Reload the data of the table view
        tableView.reloadData()
    }
    //this function makes sure that the editing will be ended once the search button is clicked
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.searchField.endEditing(true)
    }
    
    //This function makes sure that on clicking the cancel button the table reloads with the original data and the editing will be ended once the search button is clicked
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchField.text = ""
        self.searchField.endEditing(true)
        self.searchObject = self.presidentObject
        //reload the data of the table view
        tableView.reloadData()
    }

}
