//
//  PresidentTableViewCell.swift
//  NKokaUsPresidents+
//
//  Created by Gayatri on 25/10/18.
//  Copyright © 2018 Northern Illinois University. All rights reserved.
/*
 
 Author:     Naga Gayatri Koka
 Z-ID:       Z1823454
 Course:     CSCI 521, Fall 2018
 DUE:        11:59 p.m., Friday, 11/09/2018
 Instructor: Kaisone Rush
 TA:         Rajarshi Sen
 Description:
 1) This app is a tab based application. It has 3 tabs. The first tab displays all 45 presidents of United States. The user can search for a particular president, filter results based on educated or not, or presidents who served less than an year or can find the youngest and oldest presdients. The user can also sort the results based on name or party, or by order in which they became presdient. TableViewController is used to display Presidents. Each cell has president image, name, years served and party associated. When row is selected then the view will transfer to the detail view.
 2) The second tab displays all the presidents same like the first tab. But the difference is that, the user can do nested search i.e he can search for president who have no education and then among them he can select the youngest or oldest president. TableViewController is used to display Presidents. Each cell has president image, name, years served and party associated. When row is selected then the view will transfer to the detail view. And, the user can also view the number of president founds for each search.
 3) Detail view consists of details about the service years, date of birth, date of death, term, party, vice president, education, birth place, spouse, website, facts about that president, and also the user can hear the facts. The detail view consists of website button when clicked, the external website is loaded. When the facts button is clicked the facts will be displayed by a modal view controller.
 4) The third tab displays the details about the app. The about app view has send email feedback button , text view and about author button. The text view consists of details about the application. When send email feedback button is pressed, it composes a new email. When about author button is pressed view will transfer to about author view.
 5) About author view has webkit view which displays details of author who developed the application. Those details are presented in the form of a webpage.
 
 */

import UIKit

/*
 PresidentTableViewCell represents the table cell "CELL". This cell consists of outlets created to identify the imageView, title, Years served and party affiliated in the cell
 */

class PresidentTableViewCell: UITableViewCell {
    
    //Outlets to display cell image, name and subtitle and party
    @IBOutlet weak var PresidentCellImageView: UIImageView! //image
    @IBOutlet weak var PresidentTitle: UILabel!             //name
    @IBOutlet weak var PresidentSubtitle: UILabel!          //subtitle
    @IBOutlet weak var PresidentParty: UILabel!             //Party
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
