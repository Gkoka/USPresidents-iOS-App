//
//  PresidentDetailViewController.swift
//  NKokaUsPresidents+
//
//  Created by Gayatri on 26/10/18.
//  Copyright © 2018 Northern Illinois University. All rights reserved.
/*
 
 Author:     Naga Gayatri Koka
 Z-ID:       Z1823454
 Course:     CSCI 521, Fall 2018
 DUE:        11:59 p.m., Friday, 11/09/2018
 Instructor: Kaisone Rush
 TA:         Rajarshi Sen
 Description:
 1) This app is a tab based application. It has 3 tabs. The first tab displays all 45 presidents of United States. The user can search for a particular president, filter results based on educated or not, or presidents who served less than an year or can find the youngest and oldest presdients. The user can also sort the results based on name or party, or by order in which they became presdient. TableViewController is used to display Presidents. Each cell has president image, name, years served and party associated. When row is selected then the view will transfer to the detail view.
 2) The second tab displays all the presidents same like the first tab. But the difference is that, the user can do nested search i.e he can search for president who have no education and then among them he can select the youngest or oldest president. TableViewController is used to display Presidents. Each cell has president image, name, years served and party associated. When row is selected then the view will transfer to the detail view. And, the user can also view the number of president founds for each search.
 3) Detail view consists of details about the service years, date of birth, date of death, term, party, vice president, education, birth place, spouse, website, facts about that president, and also the user can hear the facts. The detail view consists of website button when clicked, the external website is loaded. When the facts button is clicked the facts will be displayed by a modal view controller.
 4) The third tab displays the details about the app. The about app view has send email feedback button , text view and about author button. The text view consists of details about the application. When send email feedback button is pressed, it composes a new email. When about author button is pressed view will transfer to about author view.
 5) About author view has webkit view which displays details of author who developed the application. Those details are presented in the form of a webpage.
 
 */

import UIKit
import AVFoundation

/* PresidentDetailViewController represents the detail view. This controller will control the data flow. It display the complete details of the selected cell. The details include image, date of birth, date of death, party affliated, term, spouse, education, vice president, birth place, website, facts, start year and end year. These outlets are used to set the data about a selected cell.
 */

class PresidentDetailViewController: UIViewController {
    
    //Outlets to display data
    @IBOutlet weak var fullImage: UIImageView!
    @IBOutlet weak var birthLabel: UILabel!
    @IBOutlet weak var deathLabel: UILabel!
    @IBOutlet weak var partyAffliated: UILabel!
    @IBOutlet weak var termLabel: UILabel!
    @IBOutlet weak var spouseLabel: UITextView!
    @IBOutlet weak var educationLabel: UILabel!
    @IBOutlet weak var vpLabel: UILabel!
    @IBOutlet weak var birthPlaceLabel: UILabel!
    @IBOutlet weak var websiteButton: UIButton!
    @IBOutlet weak var playLabel: UILabel!
    @IBOutlet weak var startLabel: UILabel!
    @IBOutlet weak var endLabel: UILabel!
    
    //Variables to hold data passed from the PresidentsTableViewController
    var name : String!          //name
    var image : String!         //image
    var dob : String!           //date of birth
    var dod : String!           //date of death
    var term : String!          //term
    var party : String!         //party affliated
    var spouse : String!        //Spouse
    var education : String!     //Education
    var vp : String!            //Vice President
    var birthPlace : String!    //Birth Place
    var website : String!       //Website
    var facts : String!         //Facts
    var startYear : String!     //start year
    var endYear : String!       //end year
    var synthesizer: AVSpeechSynthesizer!   //holds the state
    
    //audioButton function is used to play the facts based on the state
    @IBAction func audioButton(_ sender: UIButton) {
        //Holds the facts
        let utterace = AVSpeechUtterance(string: facts)
        //Setting the voice to English US
        utterace.voice = AVSpeechSynthesisVoice(language: "en-US")
        //Setting the speed of voice
        utterace.rate = 0.50
        //Setting the pitch
        utterace.pitchMultiplier = 1
        
        //guard statement to check the title
        guard let title = sender.title(for: .normal) else {return}
        
        //if title is play or resume
        if title == "Play" || title == "Resume"
        {
            //if the state is paused
            if synthesizer.isPaused
            {
                //resumes from where it stopped
                synthesizer.continueSpeaking()
                //sets the title of sender to Play
                sender.setTitle("Play", for: .normal)
                //Setting the play label to play
                 playLabel.text = "Play"
               
            }//end if
            
            //if state is speaking
            else if !synthesizer.isSpeaking
            {
               synthesizer.speak(utterace)
                
            }//end else if
        }//end if
            
        //if title is pause
        else if title == "Pause"
        {
            //if the state is speaking
            if synthesizer.isSpeaking
            {
                //pause the speaking immediately
                synthesizer.pauseSpeaking(at: AVSpeechBoundary.immediate)
                //set the playLabel to resume
                 playLabel.text = "Resume"
            }
        }//end else if
            
        //if title is stop
        else if title == "Stop"
        {
            //if the state is speaking
            if synthesizer.isSpeaking
            {
                //stop the speaking immidiately
                synthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
                //set the play label to play
                 playLabel.text = "Play"
            }//end if
        }//end else if
            
        else
        {
            return
        }
    }//end func
    
    //This function will make sure that the synthesizer state is stop when the view changes or disappears
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        //hidding the tab bar
        self.tabBarController?.tabBar.isHidden = true
        //setting the state to stopSpeaking
        synthesizer.stopSpeaking(at: AVSpeechBoundary.immediate)
    }//end func
    
    //Implementing the viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //setting the title of navigation item to name
        navigationItem.title = name
        
        //Converting the image based on the given URL
        if let url = URL(string: image!) {
            do {
                let x = try Data(contentsOf: url)
                self.fullImage.image = UIImage(data: x)
            }
            //if image is not found
            catch let ImageError {
                print("Unable to read image",ImageError)
            }
        }//end if
        
        //Setting the variables of the detail view controller
        self.birthLabel.text = dob
        //if the dod is not empty
        if(!dod.isEmpty)
        {
            self.deathLabel.text = dod
        }
        //if dod is empty set the text of that label to none
        else
        {
           self.deathLabel.text = "None"
        }
        self.partyAffliated.text = party
        self.termLabel.text = term
       self.spouseLabel.text = spouse
        self.educationLabel.text = education
       self.vpLabel.text = vp
        self.birthPlaceLabel.text = birthPlace
        self.startLabel.text = startYear
        //if the end year is not given then set the text of that label to Present
        self.endLabel.text = endYear!.isEmpty ? "Present" : endYear!
        
        

        // Do any additional setup after loading the view.
    }
    
    //Prepare function uses segue to pass data from detailView controller to both WebViewController and FactsViewController
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //To identify whether WEBVIEW segue is activated
        if(segue.identifier == "WEBVIEW")
        {
            //Assign the value of destination viewController to destVC
            let destVC = segue.destination as! WebViewController
            //Assign the website value to webUrl
             destVC.webUrl = website
        }//end if
        
        //To identify whether FACTS segue is activated
        if(segue.identifier == "FACTS")
        {
            //Assign the value of destination viewController to destVC
            let destVC = segue.destination as! FactsViewController
            //Assigning the value of facts and name
            destVC.facts = facts
            destVC.name = name
        }//end if
    }//end func

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
