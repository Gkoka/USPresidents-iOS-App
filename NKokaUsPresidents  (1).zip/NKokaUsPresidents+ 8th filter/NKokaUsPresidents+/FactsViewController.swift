//
//  FactsViewController.swift
//  NKokaUsPresidents+
//
//  Created by Gayatri on 07/11/18.
//  Copyright © 2018 Northern Illinois University. All rights reserved.
/*

 Author:     Naga Gayatri Koka
 Z-ID:       Z1823454
 Course:     CSCI 521, Fall 2018
 DUE:        11:59 p.m., Friday, 11/09/2018
 Instructor: Kaisone Rush
 TA:         Rajarshi Sen
 Description:
 1) This app is a tab based application. It has 3 tabs. The first tab displays all 45 presidents of United States. The user can search for a particular president, filter results based on educated or not, or presidents who served less than an year or can find the youngest and oldest presdients. The user can also sort the results based on name or party, or by order in which they became presdient. TableViewController is used to display Presidents. Each cell has president image, name, years served and party associated. When row is selected then the view will transfer to the detail view.
 2) The second tab displays all the presidents same like the first tab. But the difference is that, the user can do nested search i.e he can search for president who have no education and then among them he can select the youngest or oldest president. TableViewController is used to display Presidents. Each cell has president image, name, years served and party associated. When row is selected then the view will transfer to the detail view. And, the user can also view the number of president founds for each search.
 3) Detail view consists of details about the service years, date of birth, date of death, term, party, vice president, education, birth place, spouse, website, facts about that president, and also the user can hear the facts. The detail view consists of website button when clicked, the external website is loaded. When the facts button is clicked the facts will be displayed by a modal view controller.
 4) The third tab displays the details about the app. The about app view has send email feedback button , text view and about author button. The text view consists of details about the application. When send email feedback button is pressed, it composes a new email. When about author button is pressed view will transfer to about author view.
 5) About author view has webkit view which displays details of author who developed the application. Those details are presented in the form of a webpage.
 
 */

import UIKit

/* FactsViewController will control the facts view in the story board. It displays the facts about the president passed from the DetailViewController. The user can dismiss the view by swiping it in any direction.
 */
class FactsViewController: UIViewController {
    
    //Outlet for the title and facts text view
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var factsTV: UITextView!
    
    //Variables to hold data passed from the presidentDetailViewController
    var name : String!      //Variable to store name
    var facts : String!     //Variable to store facts
    
    //Implementing the viewDidLoad function
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Place sent data into their outlets
        titleLabel.text = "Facts about \(name!)"
        self.factsTV.text = facts
        
        //This is used to store the dragging gestures of the user on screen
        let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(panGestureRecognizerAction(_:)))
        //Adding the gesture recognizer to the current view
        self.view.addGestureRecognizer(panGestureRecognizer)

        // Do any additional setup after loading the view.
    }
    
    /* panGestureRecognizerAction is used to dismiss the view based on the velocity of dragging
    */
    
    @objc func panGestureRecognizerAction(_ gesture : UIPanGestureRecognizer) {
        //Variable used to store the position where the user is dragging
        let translation = gesture.translation(in: view)
        //Used to move the view to the position stored in translation
        view.frame.origin = translation
        //Checking if the dragging is ended and the velocity of dragging
        if gesture.state == .ended {
            //Holds the velocity of dragging
            let velocity = gesture.velocity(in: view)
            //Condition for velocity
            if velocity.y >= 500 || velocity.y <= 500  {
                //Dismiss the view based on the velocity
                self.dismiss(animated: true, completion: nil)
            }
            //if the velocity is less, restore to its original position
            else {
                UIView.animate(withDuration: 0.1, animations: {
                    //restore to original position
                    self.view.frame.origin = CGPoint(x: 0, y: 0)
                    })
            }
        }//end if
    }//end of func

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
