//
//  AboutAppViewController.swift
//  NKokaUsPresidents+
//
//  Created by Gayatri on 27/10/18.
//  Copyright © 2018 Northern Illinois University. All rights reserved.
/*
 
 Author:     Naga Gayatri Koka
 Z-ID:       Z1823454
 Course:     CSCI 521, Fall 2018
 DUE:        11:59 p.m., Friday, 11/09/2018
 Instructor: Kaisone Rush
 TA:         Rajarshi Sen
 Description:
 1) This app is a tab based application. It has 3 tabs. The first tab displays all 45 presidents of United States. The user can search for a particular president, filter results based on educated or not, or presidents who served less than an year or can find the youngest and oldest presdients. The user can also sort the results based on name or party, or by order in which they became presdient. TableViewController is used to display Presidents. Each cell has president image, name, years served and party associated. When row is selected then the view will transfer to the detail view.
 2) The second tab displays all the presidents same like the first tab. But the difference is that, the user can do nested search i.e he can search for president who have no education and then among them he can select the youngest or oldest president. TableViewController is used to display Presidents. Each cell has president image, name, years served and party associated. When row is selected then the view will transfer to the detail view. And, the user can also view the number of president founds for each search.
 3) Detail view consists of details about the service years, date of birth, date of death, term, party, vice president, education, birth place, spouse, website, facts about that president, and also the user can hear the facts. The detail view consists of website button when clicked, the external website is loaded. When the facts button is clicked the facts will be displayed by a modal view controller.
 4) The third tab displays the details about the app. The about app view has send email feedback button , text view and about author button. The text view consists of details about the application. When send email feedback button is pressed, it composes a new email. When about author button is pressed view will transfer to about author view.
 5) About author view has webkit view which displays details of author who developed the application. Those details are presented in the form of a webpage.
 
 */

import UIKit
import MessageUI

/*  AboutAppViewController will control the data flow in about app view. This view consists of details about the app and the version. It also has two buttons, the About Author which when clicked will display the about author view and Send Email Feedback button which when clicked composes the email. The user will be able to dismiss the view by clicking the back navigation welcome button */

class AboutAppViewController: UIViewController, MFMailComposeViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
     This function pushes the view controller when Send Email Feedback button is pressed.
     */
    
    @IBAction func sendEmail(_ sender: UIButton)
    {
        //ViewController to compose the email using MFMailComposeViewController()
        let mailComposeVC = MFMailComposeViewController()
        //making mail compose view controller to be it's own delegate
        mailComposeVC.mailComposeDelegate = self
        //email address
        let toRecipients = ["niucsci@gmail.com"]
        //email subject title
        let emailTitle = "NKokaTopTenNorthBend"
        //message body
        let messageBody = "Naga Gayatri Koka, Z1823454, MONDAY, 10/15/2018, 11:59 pm"
        //set the recepients to the mail compose view controller
        mailComposeVC.setToRecipients(toRecipients)
        //set the subject title to the mail compose view controller
        mailComposeVC.setSubject(emailTitle)
        //set the message body to the mail compose view controller
        mailComposeVC.setMessageBody(messageBody, isHTML: false)
        //present the mail compose view controller
        self.present(mailComposeVC, animated: true, completion: nil)
    }
    
    //This function is used for dismissing the compose view controller after it finishes
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?)
    {
        //dismiss the compose view controller
        self.dismiss(animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
